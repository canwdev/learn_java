package com.sirius.main;

import java.util.Scanner;

public class User implements AccountAPI{
	double balance=salary;
	void behabior(AccountAPI k){
		k.ctrl();
	}
/*
 * (non-Javadoc)
 * @see com.sirius.main.AccountAPI#ctrl()
 * @Override
	public void ctrl() {
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		double money,balance=salary;
		int control = -1;
		while (control!=0) {
			System.out.println("1.��Ǯ\t2.ȡǮ\t3.�鿴���");
			control = scanner.nextInt();
			switch (control) {
			case 1:
				System.out.print("������Ҫ����Ľ�");
				money = scanner.nextDouble();
				balance = balance + money;
				System.out.println("����Ľ��Ϊ:" + money + "\n���Ϊ:" + balance);
				break;
			case 2:
				System.out.print("������Ҫȡ���Ľ�");
				money = scanner.nextDouble();
				balance = balance - money;
				System.out.println("ȡ���Ľ��Ϊ:" + money + "\n���Ϊ:" + balance);
				break;
			case 3:
				System.out.println("���Ϊ:" + balance);
				break;
			case 0:
				System.out.println("ллʹ��");
				try {
					Thread.sleep(1000);
				} catch (Exception e) {
					// TODO: handle exception
				}
				System.exit(0);
				break;
			}
		}
	}
 */

	@Override
	public void ctrl() {
		
	}
	
}
