package com.sirius.main;

import java.util.Scanner;

public class InitMain {

	public static void main(String[] args) {
		final Scanner scanner=new Scanner(System.in);
		final User user=new User();
		int control = -1;
		while (control!=0) {
			System.out.println("1.��Ǯ\t2.ȡǮ\t3.�鿴���");
			control = scanner.nextInt();
			switch (control) {
			case 1:
				user.behabior(new AccountAPI() {

					@Override
					public void ctrl() {
						double money;
						System.out.print("������Ҫ����Ľ�");
						money = scanner.nextDouble();
						user.balance = user.balance + money;
						System.out.println("����Ľ��Ϊ:" + money + "\n���Ϊ:" + user.balance);
					}
				});
				break;
			case 2:
				user.behabior(new AccountAPI() {

					@Override
					public void ctrl() {
						double money;
						System.out.print("������Ҫȡ���Ľ�");
						money = scanner.nextDouble();
						user.balance = user.balance - money;
						System.out.println("ȡ���Ľ��Ϊ:" + money + "\n���Ϊ:" + user.balance);				
					}
				});
				break;
			case 3:
				user.behabior(new AccountAPI() {

					@Override
					public void ctrl() {
						double money,balance=salary;
						System.out.println("���Ϊ:" + balance);			
					}
				});
				break;
			case 0:
				System.out.println("ллʹ��");
				try {
					Thread.sleep(1000);
				} catch (Exception e) {
					// TODO: handle exception
				}
				System.exit(0);
				break;
			}

		}

	}

}
