package com.sirius.main;

public interface AccountAPI {
	static double salary=10000;
	abstract void ctrl();
}
